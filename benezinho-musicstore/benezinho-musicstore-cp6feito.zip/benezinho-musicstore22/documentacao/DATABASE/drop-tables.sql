-- Tables: 


drop table  TB_ARTISTA  CASCADE CONSTRAINTS;
drop table  TB_MUSIC  CASCADE CONSTRAINTS;



-- SEQUENCIAS:

drop sequence  SQ_ARTISTA;
drop sequence  SQ_MUSIC
 